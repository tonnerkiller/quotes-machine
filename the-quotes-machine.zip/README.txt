A Pen created at CodePen.io. You can find this one at https://codepen.io/tonnerkiller/pen/xpPYmv.

 The pen, once completed, is meant to retrieve a random quote from some free quote APIs and display it. A new quote shall be displayed when a button is clicked.
There is also social media sharing to Twitter and Hubzilla as an example for a decentralised network. 
Data is sent by window.open() and a query string, as this is the easiest way to circumvent same-origin policy. Actually like this it is calling server side code and giving parameters, rather than sending data to the server.

This is from the freeCodeCamp "Random Quote Generator" challenge.